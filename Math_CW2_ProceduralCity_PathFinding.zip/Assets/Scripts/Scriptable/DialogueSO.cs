﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(menuName ="Dialogue/DialogueTexts")]
public class DialogueSO : ScriptableObject
{
    public List<string> DialogueText;
}
