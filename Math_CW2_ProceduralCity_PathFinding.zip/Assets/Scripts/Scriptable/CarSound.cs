﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;



[CreateAssetMenu(menuName ="EngineSound")]
public class CarSound : ScriptableObject
{
    public AudioClip[] engineSound;
    
}
