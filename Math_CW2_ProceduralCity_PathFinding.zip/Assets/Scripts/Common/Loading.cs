﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using System;
using CityGenerate;

public class Loading : MonoBehaviour {

    private WorldTargetGeneration wtg;
    private GridTesting GD;
    //private string loadName;
    private Text Text;
    private Transform Line;
    private List<string> loadText = new List<string>();

    float time = 0;
    float textfps = 5;
    int textindex = 0;
    float targetPerc = 0.1f;
    Vector2 LineScale;

    AsyncOperation loadScene;

    void Start () {
        GameState.Instance.setCurGameState(GameState.State.Loading);
        GameObject parent = GameObject.Find("LoadingCanvas");
        GameObject loading=Resources.Load("Loading/City") as GameObject;     
        loading = Instantiate(loading, parent.transform);
        loading.GetComponent<RectTransform>().anchoredPosition = new Vector2(0, 0);
        loadText.Add("Loading.");
        loadText.Add("Loading..");
        loadText.Add("Loading...");
        Text = loading.GetComponentInChildren<Text>();
   
        Line = loading.transform.Find("Black/Line");
        LineScale = Line.GetComponent<RectTransform>().localScale;
   
    }


    void Update()
    {
        if (LineScale.x >= 1)
        {
            return;
        }

       

        time += Time.deltaTime;
        if (time >= 1 / textfps)
        {
            Text.text = loadText[textindex];
            textindex++;
            if (textindex > 2)
            {
                textindex = 0;
            }        

            LineScale.x += targetPerc;
            Line.GetComponent<RectTransform>().localScale = LineScale;
          //  Debug.Log("LineScale：" + LineScale);

            time = 0;
        }     

        if (LineScale.x < 1 && loadScene == null)
        {
            StartCoroutine(LoadScene());
        }
        // Debug.Log(loadScene.progress);

    }

    IEnumerator LoadScene()
    {
        GameState.Instance.closeMainScene();
        loadScene= SceneManager.LoadSceneAsync(GameState.Instance.curSceneName, LoadSceneMode.Additive);
        loadScene.allowSceneActivation = true;
        yield return loadScene;
        SceneManager.SetActiveScene(SceneManager.GetSceneByName(GameState.Instance.curSceneName));
        
    
        while (loadScene.progress < 0.9f || LineScale.x < 1)
        {
            yield return null;

        }
        transform.GetChild(0).gameObject.SetActive(false);
        yield return StartCoroutine(Turtle.Instance.generate());
        while (!Turtle.Instance.isFinished)
        {
            yield return new WaitForSeconds(0.1f);
        }
        //Generate characters
        //Debug.Log(SceneManager.GetSceneAt(2).name);
        /*
        if(SceneManager.GetSceneByName("city 1").isLoaded)
        {
            GD = SceneManager.GetSceneByName("city 1").GetRootGameObjects()[1].GetComponent<GridTesting>();
            GD.CreateGrid();
            //Debug.Log("Wrong Enter");
        }else if(SceneManager.GetSceneByName("city 2").isLoaded)
        {
            GD = SceneManager.GetSceneByName("city 2").GetRootGameObjects()[1].GetComponent<GridTesting>();
            GD.CreateGrid();
            //Debug.Log(GD.name);
        }*/

        if (SceneManager.GetSceneByName(GameState.Instance.curSceneName).isLoaded)
        {
            GD = SceneManager.GetSceneByName(GameState.Instance.curSceneName).GetRootGameObjects()[1].GetComponent<GridTesting>();
            GD.CreateGrid();
            //Debug.Log("Wrong Enter");
        }
        //call generate city funtion

        // loadScene.allowSceneActivation = true;
        GameState.Instance.setCurGameState(GameState.State.Game);
        SceneManager.UnloadSceneAsync("Loading");
    }

  
}
