﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using Singleton;
using CityGenerate;

public class GameState : SingleInstance<GameState>
{
    public enum State
    {      
        Main,
        Loading,
        Game,
        CarGame,
    }

    public struct SceneInfo
    {
        public string name;
        public int id;
        public float natureChance;
        public string imagePath;
        public string skyboxPath;
    }

    public State curState { get { return _curState; } }
    private State _curState = State.Main;

    public int curSceneId { get { return _curSceneId; } }
    private int _curSceneId;

    public string curSceneName { get { return _curSceneName; } }
    private string _curSceneName;

    public string preSceneName { get { return _preSceneName; } }
    private string _preSceneName;

    public float curNatureChance { get { return _curNatureChance; } }
    private float _curNatureChance;

    public bool requiredAnimation { get { return _requiredAnimation; } }
    private bool _requiredAnimation = true;
    
 
    public void setCurGameState(State s)
    {
        _curState = s;
        if(_curState == State.Main)
        {
            _preSceneName = _curSceneName;
            _curSceneName = null;
            _curSceneId = -1;           
            //Camera.main.gameObject.SetActive(true);
            UIcontroller.Instance.showMainPnl();
        }
        else if(_curState == State.Game)
        {
            UIcontroller.Instance.showGamePnl();
            UIcontroller.Instance.enableCarView();
            AudioListener audio = Camera.main.gameObject.GetComponent<AudioListener>();
            if (!audio.enabled)
            {
                audio.enabled = true;
            }

        }
        else if (_curState == State.Loading)
        {
            UIcontroller.Instance.showGamePnl();
           
        }
        else if(_curState == State.CarGame)
        {
            UIcontroller.Instance.enableOverView();
            AudioListener audio = Camera.main.gameObject.GetComponent<AudioListener>();
            if (audio.enabled)
            {
                audio.enabled = false;
            }


        }
    }

    public void loadScene(string sceneName, int sceneId, float natureChance)
    {    
        if(_curState != State.Main)
        {
            return;
        }
        _curSceneName = sceneName;
        _curSceneId = sceneId;
        _curNatureChance = natureChance;
        SceneManager.LoadScene("Loading", LoadSceneMode.Additive);
    }

    //first enter or returning to the mainscene, if there is another scene, should unload it firstly
    public void showMainScene()
    {

        leaveCurScene();
        SceneManager.SetActiveScene(SceneManager.GetSceneByName("Main"));
        // DialogControl.Instance.showMainHall();
        setCurGameState(State.Main);

    }

    public void leaveCurScene()
    {
        if (_curSceneName != null)
        {
            RoadMgr.Instance.reset();
            BuildingMgr.Instance.reset();
            SceneManager.UnloadSceneAsync(_curSceneName);

        }
    }

    //just disable the canvas
    public void closeMainScene()
    {


    }

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
