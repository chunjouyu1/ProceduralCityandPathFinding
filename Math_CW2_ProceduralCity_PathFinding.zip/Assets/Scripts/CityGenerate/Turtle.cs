﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
using Singleton;


namespace CityGenerate {

    public class Turtle : SingleInstance<Turtle>
    {

        private class LSystemState
        {
           
            public float angle = 0;
            public Vector3 position = Vector3.zero;
            public bool mainRoad = true;

            public LSystemState Clone()
            {
                return (LSystemState)this.MemberwiseClone();
            }
        }

        private LSystem _lSystem = new LSystem();

        private LSystemState curState;
        private float _angle = 0;
        private float _mainRoadChance = 0;
        private int _maxLength = 0;
        private int _minLength = 0;
        private int _roadSize = 0;

        public bool isFinished { get { return _isFinished; } }
        private bool _isFinished = false;

        public void setData()
        {
            _angle = _lSystem.curTurtleData.angle;
            _roadSize = _lSystem.curTurtleData.roadSize;          
            _mainRoadChance = _lSystem.curTurtleData.mainRoadChance;
            _maxLength = _lSystem.curTurtleData.maxLength;
            _minLength = _lSystem.curTurtleData.minLength;
           
        }


       
        public IEnumerator generate()
        {
            _isFinished = false;
            string sentence;
            sentence = _lSystem.getNewSentence();       

            if (sentence == null)
            {
                _isFinished = true;
                yield break;
            }
            Debug.Log(sentence);

            curState = new LSystemState();            
            int length = 1;
            if(GameState.Instance.preSceneName != GameState.Instance.curSceneName)
            {
                setData();
            }
            RoadMgr.Instance.setObject();
            BuildingMgr.Instance.initBuildingData();
            Stack<LSystemState> stateStack = new Stack<LSystemState>();

            Vector3 direction = Vector3.forward;
            Vector3 tempPosition = Vector3.zero;

            
            for (int i = 0; i < sentence.Length; i++)
            {
                char c = sentence[i];
                if (_lSystem.curTurtleData.roadSymbol.Contains(c.ToString()))
                {
                    tempPosition = curState.position;
                    length = UnityEngine.Random.Range(_minLength, _maxLength + 1);
                    direction = Quaternion.AngleAxis(curState.angle, Vector3.up) * direction;
                    RoadMgr.Instance.storeRoadPositionInfo(tempPosition, direction, length, _mainRoadChance);
                    curState.position += _roadSize * length * direction;
                    
                }
                else
                {
                    switch (c)
                    {
                        case '+':
                            curState.angle += _angle;
                            break;
                        case '-':
                            curState.angle -= _angle;
                            break;
                        case '[':
                            stateStack.Push(curState.Clone());
                            break;
                        case ']':
                            curState = stateStack.Pop();
                            break;
                        default:
                            break;
                    }
                }

            }
           
            StartCoroutine(RoadMgr.Instance.placeRoadPosition(_roadSize, _lSystem.curTurtleData.zebraChance));
            while (RoadMgr.Instance.waitingForRoad)
            {
                yield return new WaitForSeconds(0.01f);
            }                 
            StartCoroutine(RoadMgr.Instance.placePavementRoads(_roadSize, _lSystem.curTurtleData.pavementWidth));
            while (RoadMgr.Instance.waitingForRoad)
            {
                yield return new WaitForSeconds(0.01f);
            }

            RoadMgr.Instance.fixTurnRoad(_roadSize);
            RoadMgr.Instance.fixZebraRoad(_roadSize, _lSystem.curTurtleData.zebraMaxNumOneRoad);
          
            StartCoroutine(BuildingMgr.Instance.placeBuildings(_lSystem.curTurtleData.pavementWidth, _roadSize));
            while (BuildingMgr.Instance.waitingForBuilding)
            {
                yield return new WaitForSeconds(0.01f);
            }
            _isFinished = true;
        }
      
        

    }
}
