﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Singleton;


namespace CityGenerate
{
    public enum Direction
    {
        Up,
        Down,
        Right,
        Left
    }

    public enum RoadType
    {
        Main,
        Path,
   
    }

    public class RoadMgr : SingleInstance<RoadMgr>
    {
        public struct roadPosInfo
        {
            public Vector3 startPos;
            public Vector3 direction;
            public int length;
            public RoadType roadType;
            public Direction diretionType;
        }
        public Dictionary<Vector3Int, GameObject> roadDic = new Dictionary<Vector3Int, GameObject>();
        public Dictionary<Vector3Int, GameObject> pavementDic = new Dictionary<Vector3Int, GameObject>();
        public Dictionary<Vector3Int, Direction> zebraDic = new Dictionary<Vector3Int, Direction>();
        private Dictionary<Vector3Int, Direction> pavementDirectionDic = new Dictionary<Vector3Int, Direction>();
        public HashSet<Vector3Int> roadBranchSet = new HashSet<Vector3Int>();
        public List<roadPosInfo> roadInfoList = new List<roadPosInfo>();
        private Vector3Int[] edgeRoadList;
        private GameObject road3, road4, pavement, zebra, turnroad;
        private GameObject cityParent;
        //  private int _roadSize, _pavementSize;

        public bool waitingForRoad = false;
        private float animationTime = 0.00001f;

        public Vector3 initPosition { get { return _initPosition; } }
        private Vector3 _initPosition;
        


        public Dictionary<Vector3Int, Direction> getPavementPositions()
        {
            return pavementDirectionDic;
        }

        public void setObject()
        {
            cityParent = GameObject.Find("Roads");
            if (!cityParent)
            {
                cityParent = new GameObject("Roads");

            }
            if (GameState.Instance.curSceneName != null && GameState.Instance.preSceneName == GameState.Instance.curSceneName)
            {
                return;
            }
            
            GameObject[] roadObjects = Resources.LoadAll<GameObject>("Prefabs/" + GameState.Instance.curSceneName + "/Roads");
            foreach (GameObject o in roadObjects)
            {
                if (o.name.Contains("road3"))
                {
                    road3 = o;
                }
                else if (o.name.Contains("road4"))
                {
                    road4 = o;
                }
                else if (o.name.Contains("pavement"))
                {
                    pavement = o;
                }
                else if (o.name.Contains("zebra"))
                {
                    zebra = o;
                }
                else if (o.name.Contains("turnroad"))
                {
                    turnroad = o;
                }
            }
        }

        public void storeRoadPositionInfo(Vector3 startPos, Vector3 direction, int length, float mainRoadChance)
        {
            roadPosInfo info = new roadPosInfo();
            info.startPos = startPos;
            info.direction = direction;
            info.length = length;
            if(Random.value <= mainRoadChance)
            {
                info.roadType = RoadType.Main;
            }
            else
            {
                info.roadType = RoadType.Path;
            }

            if (Vector3Int.RoundToInt(direction).x < 0)
            {
                info.diretionType = Direction.Left;
            }
            else if (Vector3Int.RoundToInt(direction).x > 0)
            {
                info.diretionType = Direction.Right;
            }
            else if (Vector3Int.RoundToInt(direction).z < 0)
            {
                info.diretionType = Direction.Down;
            }
            else if (Vector3Int.RoundToInt(direction).z > 0)
            {
                info.diretionType = Direction.Up;
            }

            roadInfoList.Add(info);
        }

        public IEnumerator placeRoadPosition(int roadSize, float zebraChance)
        {
            if(roadInfoList.Count <= 0)
            {
                yield break;
            }
            bool isBeginning = true;
            edgeRoadList = new Vector3Int[2];
            waitingForRoad = GameState.Instance.requiredAnimation;

            for (int j = 0; j < roadInfoList.Count; j++)
            {
                roadPosInfo info = roadInfoList[j];
                Quaternion rotation = Quaternion.identity;
                if (info.diretionType == Direction.Left || info.diretionType == Direction.Right)
                {
                    rotation = Quaternion.Euler(0, 90, 0);
                }
                GameObject newRoad1;
                GameObject newRoad2;
                int tempi = 1;
                Vector3Int sPos = Vector3Int.RoundToInt(info.startPos);
                while (roadDic.ContainsKey(sPos))
                {                   
                    sPos = Vector3Int.RoundToInt(info.startPos + info.direction * roadSize * tempi);
                    tempi++;
                }
                info.startPos = sPos;
               
                bool change = checkChangeRoadType(info.startPos, info.direction, info.roadType, roadSize);
                if (change)
                {
                    if(info.roadType == RoadType.Main)
                    {
                        info.roadType = RoadType.Path;
                    }
                    else
                    {
                        info.roadType = RoadType.Main;
                    }
                }
               
                
                for (int i = 0; i < info.length; i++)
                {                 
                    Vector3Int pos = Vector3Int.RoundToInt(info.startPos + info.direction * roadSize * i);
                    if (roadDic.ContainsKey(pos))
                    {
                        continue;
                    }
    
                    if(info.roadType == RoadType.Main)
                    {
                        Vector3Int pos2 = Vector3Int.RoundToInt(pos + Quaternion.AngleAxis(-90, Vector3.up) * info.direction * roadSize);
                        if (roadDic.ContainsKey(pos2))
                        {
                            continue;
                        }


                        if ((i == 0 || i == info.length - 1) && Random.value <= zebraChance)
                        {
                            
                            newRoad1 = Instantiate(zebra, cityParent.transform);
                            newRoad1.transform.SetPositionAndRotation(pos, rotation);
                           
                            newRoad2 = Instantiate(zebra, cityParent.transform);
                            newRoad2.transform.SetPositionAndRotation(pos2, rotation);

                            zebraDic.Add(pos, info.diretionType);
                            zebraDic.Add(pos2, info.diretionType);
                            
                        }
                        else
                        {
                            newRoad1 = Instantiate(road3, cityParent.transform);
                            newRoad1.transform.SetPositionAndRotation(pos, rotation);
                            if(info.diretionType == Direction.Left || info.diretionType == Direction.Down)
                            {
                                Vector3 scale = newRoad1.transform.localScale;
                                scale.x *= -1;
                                newRoad1.transform.localScale = scale;
                            }

                            newRoad2 = Instantiate(road3, cityParent.transform);
                            newRoad2.transform.SetPositionAndRotation(pos2, rotation);
                            if (info.diretionType == Direction.Right || info.diretionType == Direction.Up)
                            {
                                Vector3 scale = newRoad2.transform.localScale;
                                scale.x *= -1;
                                newRoad2.transform.localScale = scale;
                            }
                                
                        }
                        roadDic.Add(pos, newRoad1);
                        roadDic.Add(pos2, newRoad2);
                        
                    }
                    else
                    {
                      
                        newRoad1 = Instantiate(road4, cityParent.transform);
                        newRoad1.transform.SetPositionAndRotation(pos, rotation);
                        roadDic.Add(pos, newRoad1);
                        
                    }
                    if (isBeginning)
                    {
                        _initPosition = pos;
                    }

                    if (i == 0 || i == info.length - 1)
                    {
                        roadBranchSet.Add(pos);
                        if (info.diretionType == Direction.Down || info.diretionType == Direction.Left)
                        {

                            if (i == 0)
                            {
                                if (edgeRoadList[1] == null)
                                {
                                    edgeRoadList[1] = pos;
                                    
                                }
                                else if (pos.z > edgeRoadList[1].z)
                                {
                                    edgeRoadList[1].z = pos.z;
                                }
                                else if (pos.x > edgeRoadList[1].x)
                                {
                                    edgeRoadList[1].x = pos.x;
                                }
                            }
                            else if (i == info.length - 1)
                            {
                                if (edgeRoadList[0] == null)
                                {
                                    edgeRoadList[0] = pos;
                                 
                                }
                                else if (pos.z < edgeRoadList[0].z)
                                {
                                    edgeRoadList[0].z = pos.z;
                                }
                                else if (pos.x < edgeRoadList[1].x)
                                {
                                    edgeRoadList[0].x = pos.x;
                                }

                            }
                        }
                        else if (info.diretionType == Direction.Up || info.diretionType == Direction.Right)
                        {

                            if (i == 0)
                            {
                                if (edgeRoadList[0] == null)
                                {
                                    edgeRoadList[0] = pos;
                                  
                                }
                                else if (pos.z < edgeRoadList[0].z)
                                {
                                    edgeRoadList[0].z = pos.z;
                                }
                                else if (pos.x < edgeRoadList[1].x)
                                {
                                    edgeRoadList[0].x = pos.x;
                                }
                            }
                            else if (i == info.length - 1)
                            {
                                if (edgeRoadList[1] == null)
                                {
                                    edgeRoadList[1] = pos;
                                 
                                }
                                else if (pos.z > edgeRoadList[1].z)
                                {
                                    edgeRoadList[1].z = pos.z;
                                }
                                else if (pos.x > edgeRoadList[1].x)
                                {
                                    edgeRoadList[1].x = pos.x;
                                }

                            }
                        }
                    }

                    setCamera(edgeRoadList, isBeginning);

                    if (isBeginning)
                    {
                        isBeginning = false;
                    }
                    
                  
                    if (GameState.Instance.requiredAnimation)
                    {
                        yield return new WaitForSeconds(animationTime);
                    }
                   

                }
            }
            waitingForRoad = false;
            CameraMove.Instance.initMoveCamera(edgeRoadList);
        }

        private float preMaxDistance = 0;
        private void setCamera(Vector3Int[] edgePoints, bool isBeginning)
        {
            Vector3? pos = null;
            float maxDis = 0;
            //Debug.Log("edge:" + edgePoints[0] + ", " + edgePoints[1]);
            if (isBeginning)
            {
                if(edgePoints[0] != null)
                {
                    pos = edgePoints[0];
                }
                else if(edgePoints[1] != null)
                {
                    pos = edgePoints[1];
                }
            }
            else if(edgePoints[0] != null && edgePoints[1] != null)
            {
                pos = (edgePoints[0] + edgePoints[1]) / 2;
                float disX = edgePoints[1].x - edgePoints[0].x;
                float disY = edgePoints[1].z - edgePoints[0].z;
                maxDis = disX > disY ? disX : disY;
                if(preMaxDistance == maxDis)
                {
                    return;
                }
                preMaxDistance = maxDis;
               // Debug.Log(maxDis);
            }
            if (pos == null)
                return;    
            Vector3 cameraPos = Camera.main.transform.position;
            float cameraY = cameraPos.y;
            float cameraX = cameraPos.x;
            float cameraZ = cameraPos.z;
            cameraPos = (Vector3)pos;
            cameraPos.y = Mathf.Lerp(cameraY, cameraPos.y + maxDis, Time.deltaTime * 2f);
            cameraPos.x = Mathf.Lerp(cameraX, cameraPos.x, Time.deltaTime * 3);
            cameraPos.z = Mathf.Lerp(cameraZ, cameraPos.z, Time.deltaTime * 3);
            Quaternion rotation = Quaternion.Euler(90, 0, 0);
            Camera.main.transform.SetPositionAndRotation(cameraPos, rotation);
        }

        public IEnumerator placePavementRoads(int roadSize, int pavementSize)
        {
          
            waitingForRoad = GameState.Instance.requiredAnimation;
            GameObject pavementRoad;
            Dictionary<Vector3Int, Direction> freePosList = PlacementMgr.GetAvaliablePositions(roadDic.Keys, roadSize, pavementSize);
            foreach(var pos in freePosList.Keys)
            {
                if (!pavementDic.ContainsKey(pos))
                {
                    pavementRoad = Instantiate(pavement, cityParent.transform);
                    Quaternion rotation = Quaternion.identity;
                    Direction d = freePosList[pos];
                    if(d == Direction.Up || d == Direction.Down)
                    {
                        rotation = Quaternion.Euler(0, 90, 0);
                    }
                   
                    pavementRoad.transform.SetPositionAndRotation(pos, rotation);
                    pavementDic.Add(pos, pavementRoad);
                    pavementDirectionDic.Add(pos, d);
                  
                }
                if (GameState.Instance.requiredAnimation)
                {
                    yield return new WaitForSeconds(animationTime);
                }
                
            }
            waitingForRoad = false;

        }

        //change the RoadType when return true 
        public bool checkChangeRoadType(Vector3 startPos, Vector3 direction, RoadType type, int roadSize)
        {
            Vector3Int pos = Vector3Int.RoundToInt(startPos - direction * roadSize);
            Vector3Int pos2 = Vector3Int.RoundToInt(pos + Quaternion.AngleAxis(-90, Vector3.up) * direction * roadSize);
            if ((roadDic.ContainsKey(pos) && roadDic.ContainsKey(pos2)))
            {
                if (type == RoadType.Main)
                {
                    return false;
                }
                else
                {
                    return true;
                }
               
            }
            else if((!roadDic.ContainsKey(pos) && !roadDic.ContainsKey(pos2)))
            {
                return true;
            }
            else
            {
                if (type == RoadType.Main)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }

            
        }

        public void fixTurnRoad(int roadSize)
        {
            if (!turnroad)
            {
                return;
            }
            foreach(var pos in roadBranchSet)
            {
                List<Direction> neighbourDirec = PlacementMgr.FindNeighbourDirections(pos, roadDic.Keys, roadSize);
                Quaternion rotation = Quaternion.identity;
                if (neighbourDirec.Count == 2)
                {
                    if (!roadDic.ContainsKey(pos))
                    {
                        continue;
                    }
                    
                    if (neighbourDirec.Contains(Direction.Down))
                    {
                        if (neighbourDirec.Contains(Direction.Left))
                        {
                            rotation = Quaternion.Euler(0, -90, 0);
                        }
                        else if (neighbourDirec.Contains(Direction.Right))
                        {
                            rotation = Quaternion.Euler(0, -180, 0);
                        }
                    }
                    if (neighbourDirec.Contains(Direction.Up))
                    {
                        if (neighbourDirec.Contains(Direction.Left))
                        {
                            rotation = Quaternion.Euler(0, 0, 0);
                        }
                        else if (neighbourDirec.Contains(Direction.Right))
                        {
                            rotation = Quaternion.Euler(0, 90, 0);
                        }
                    }
                    Destroy(roadDic[pos]);
                    GameObject fixRoad = Instantiate(turnroad, cityParent.transform);
                    fixRoad.transform.SetPositionAndRotation(pos, rotation);
                }
            }
        }

        public void fixZebraRoad(int size, int maxZebraNum)
        {
           
            Dictionary<Vector3Int, Direction> tempRoads = new Dictionary<Vector3Int, Direction>();
            Dictionary<Vector3Int, Direction> tempZebras = new Dictionary<Vector3Int, Direction>();
            List<Vector3Int> tempPositions = new List<Vector3Int>();
            foreach (var pos in zebraDic.Keys)
            {             
                List<Vector3Int> directionList = PlacementMgr.GetVerticalDirectionVectors3(zebraDic[pos]);
                bool isZebra = true;
                int num = 0;
               
                foreach (var direction in directionList)
                {
                    Vector3Int roadPos = pos + direction * size;
            
                    while (roadDic.ContainsKey(roadPos))
                    {
                        if(num > maxZebraNum)
                        {
                            isZebra = false;
                            break;
                        }
                        num++;
                        if (!roadDic[roadPos].name.Contains("zebra"))
                        {
                            
                            if (!tempRoads.ContainsKey(roadPos))
                            {
                                tempRoads.Add(roadPos, zebraDic[pos]);
                                tempPositions.Add(roadPos);
                            }
                            
                        }
                        else
                        {
                            if (!tempZebras.ContainsKey(roadPos))
                            {
                                tempZebras.Add(roadPos, zebraDic[pos]);
                                tempPositions.Add(roadPos);
                            }
                            
                        }
                        
                        roadPos += direction * size;
                    }
                    if (!isZebra)
                    {
                        break;
                    }
                }

                int count = tempPositions.Count;
                for (int i = count - 1; i >= 0; i--)
                {
                    Vector3Int tempPos = tempPositions[i];
                    tempPositions.RemoveAt(i);
                    if (isZebra)
                    {
                        tempZebras.Remove(tempPos);
                    }
                    else
                    {
                        tempRoads.Remove(tempPos);
                        if (!tempZebras.ContainsKey(pos))
                        {
                            tempZebras.Add(pos, zebraDic[pos]);
                        }
                    }
                   
                }
               
            }

            foreach(var key in tempRoads.Keys)
            {
                if (zebraDic.ContainsKey(key))
                {
                    continue;
                }
               
                Destroy(roadDic[key]);
                roadDic.Remove(key);

                Quaternion rotation = Quaternion.identity;
                if (tempRoads[key] == Direction.Left || tempRoads[key] == Direction.Right)
                {
                    rotation = Quaternion.Euler(0, 90, 0);
                }
                GameObject newZebra = Instantiate(zebra, cityParent.transform);
                newZebra.transform.SetPositionAndRotation(key, rotation);
                
                roadDic.Add(key, newZebra);
                zebraDic.Add(key, tempRoads[key]);
               
            }

            foreach(var key in tempZebras.Keys)
            {
        
                Destroy(roadDic[key]);
                roadDic.Remove(key);
                zebraDic.Remove(key);

                Quaternion rotation = Quaternion.identity;
                
                if (tempZebras[key] == Direction.Left || tempZebras[key] == Direction.Right)
                {
                    rotation = Quaternion.Euler(0, 90, 0);
                }
                GameObject newRoad = Instantiate(road3, cityParent.transform);
                newRoad.transform.SetPositionAndRotation(key, rotation);
                newRoad.transform.localScale = PlacementMgr.GetNeighbourScale(key, tempZebras[key], roadDic, size);                
                roadDic.Add(key, newRoad);
                
            }
           
        }

        public void reset()
        {
            roadInfoList.Clear();
            foreach(var o in roadDic)
            {
                Destroy(o.Value);
            }
            foreach (var o in pavementDic)
            {
                Destroy(o.Value);
            }
            foreach (var o in roadDic)
            {
                Destroy(o.Value);
            }
            roadDic.Clear();
            pavementDic.Clear();
            roadDic.Clear();
            zebraDic.Clear();
            pavementDirectionDic.Clear();
            roadBranchSet.Clear();
            CameraMove.Instance.resetMoveMainCamera();
        }

     

        /*
        public bool checkPlaceRoadAvailable(Vector3Int pos, int roadSize, int pavementSize)
        {
            if (roadDic.ContainsKey(pos))
                return false;

            int count = Mathf.CeilToInt(roadSize / pavementSize);
            Vector3Int tempPos1 = pos, tempPos2 = pos, tempPos3= pos, tempPos4 = pos;
            for (int i = 1; i <= count; i++)
            {
                tempPos1 += new Vector3Int(-1, 0, 1) * pavementSize / 2;
                tempPos2 += new Vector3Int(1, 0, 1) * pavementSize / 2;
                tempPos3 += new Vector3Int(-1, 0, -1) * pavementSize / 2;
                tempPos4 += new Vector3Int(1, 0, -1) * pavementSize / 2;          
                if(pavementDic.ContainsKey(tempPos1) || pavementDic.ContainsKey(tempPos2) || pavementDic.ContainsKey(tempPos3) || pavementDic.ContainsKey(tempPos4))
                {
                    return false;
                }
            }
            return true;
        }*/


        // Start is called before the first frame update
        void Start()
        {
            
        }

        // Update is called once per frame
        void Update()
        {

        }
    }
}
