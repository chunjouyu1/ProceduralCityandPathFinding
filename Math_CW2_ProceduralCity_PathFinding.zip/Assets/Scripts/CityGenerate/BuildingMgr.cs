﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Singleton;
using System.Text;

namespace CityGenerate
{

    public enum StructureType
    {
        Road,
        Building,
        Nautre
    }
    public class BuildingType 
    {
        public int type;
        public int width;
        public int distance;
        public int maxCount;
        public float chance;
        public int curCount;
        public StructureType structureType;
        public List<string> paths = new List<string>();
        public List<GameObject> prefabs = new List<GameObject>();

        public void GetBuildingPrefabs()
        {
           
            foreach(var p in paths)
            {
                GameObject o = Resources.Load<GameObject>(p);
                prefabs.Add(o);
            }
           
        }
    }

    

    public class BuildingMgr : SingleInstance<BuildingMgr>
    {
        private Dictionary<int, List<BuildingType>> buildingTypeDic = new Dictionary<int, List<BuildingType>>();
        private Dictionary<int, BuildingType> curBuildingTypeDic = new Dictionary<int, BuildingType>();

        private Dictionary<int, List<BuildingType>> natureTypeDic = new Dictionary<int, List<BuildingType>>();
        private Dictionary<int, BuildingType> curNatureTypeDic = new Dictionary<int, BuildingType>();

        private Dictionary<Vector3Int, GameObject> buildDic = new Dictionary<Vector3Int, GameObject>();
        private Dictionary<Vector3Int, Direction> buildDirectionDic = new Dictionary<Vector3Int, Direction>();

        private GameObject buildParent;
        private GameObject natureParent;

        public bool waitingForBuilding = false;
        private float animationTime = 0.00001f;

        public void Start()
        {
            

            
            
        }

        public void initBuildingData()
        {
            if(buildingTypeDic.Count == 0)
            {
                TextAsset file = Resources.Load<TextAsset>("Files/Buildings");
                FileParser.ParseBuildingType(file.text, out buildingTypeDic);
            }
            if(natureTypeDic.Count == 0)
            {
                TextAsset file = Resources.Load<TextAsset>("Files/Natures");
                FileParser.ParseBuildingType(file.text, out natureTypeDic);
            }

            buildParent = GameObject.Find("Builds");
            if (!buildParent)
            {
                buildParent = new GameObject("Builds");

            }
            natureParent = GameObject.Find("Nautres");
            if (!natureParent)
            {
                natureParent = new GameObject("Nautres");

            }

            if (GameState.Instance.curSceneName != null && GameState.Instance.preSceneName == GameState.Instance.curSceneName)
            {
                return;
            }
            curBuildingTypeDic.Clear();
            curNatureTypeDic.Clear();

            
            /*
            StringBuilder strbuilder = new StringBuilder();
            foreach(var d in buildingTypeDic)
            {
                strbuilder.Append(d.Key + "\n");
                foreach(var info in d.Value)
                {
                    strbuilder.Append(info.type + "\n");
                    strbuilder.Append(info.width + "\n");
                    strbuilder.Append(info.distance + "\n");
                    strbuilder.Append(info.maxCount + "\n");
                    strbuilder.Append(info.chance + "\n");
                    foreach(var p in info.paths)
                    {
                        strbuilder.Append(p + "\n");
                    }
                }
            }
            Debug.Log(strbuilder.ToString());
            */

            //curBuildingTypeList = buildingTypeDic[GameState.Instance.curSceneId];         
            foreach (var build in buildingTypeDic[GameState.Instance.curSceneId])
            {
                build.GetBuildingPrefabs();
                build.structureType = StructureType.Building;
                curBuildingTypeDic.Add(build.type, build);
               
            }

            foreach (var nature in natureTypeDic[GameState.Instance.curSceneId])
            {
                nature.GetBuildingPrefabs();
                nature.structureType = StructureType.Nautre;
                curNatureTypeDic.Add(nature.type, nature);

            }

           
        }

        public BuildingType getBuildsByChance()
        {
            float sum = Random.value;
            float p = 0;

            float natureChance = Random.value;
            IDictionary<int, BuildingType> collection;
            
            if(natureChance < GameState.Instance.curNatureChance)
            {
                collection = curNatureTypeDic;
            }
            else
            {
                collection = curBuildingTypeDic;
            }
            foreach (var d in collection)
            {
                p += d.Value.chance;
                if (p >= sum)
                {
                    if (d.Value.maxCount >= 0 && d.Value.curCount >= d.Value.maxCount)
                    {
                        return getBuildsByChance();
                    }
                    return d.Value;
                }
            }

            return null;
     
        }

        public IEnumerator placeBuildings(int pavementWidth, int pavementLength)
        {
            waitingForBuilding = GameState.Instance.requiredAnimation;
            List<Vector3Int> blockedPositions = new List<Vector3Int>();
            List<Vector3Int> tempBlocked = new List<Vector3Int>();
            Dictionary<Vector3Int, Direction> positions = RoadMgr.Instance.getPavementPositions();
            foreach(var info in positions)
            {
                BuildingType buildType = getBuildsByChance();
                if (buildType != null)
                {
                    if (!blockedPositions.Contains(info.Key))
                    {
                        bool avaliable = true;
                        int num = Mathf.CeilToInt(buildType.distance / pavementLength);
                        
                        Vector3Int paveDirVector = PlacementMgr.GetDirectionVector3(info.Value);
                        List< Vector3Int> verticalDirList = PlacementMgr.GetVerticalDirectionVectors3(info.Value);

                        foreach (var d in verticalDirList)
                        {
                            int count = Mathf.FloorToInt(num / 2);
                            Vector3Int edgePos = info.Key + count * d * pavementLength;
                            int num2 = Mathf.CeilToInt(buildType.width / pavementWidth) + 1;
                            num2 = num2 <= 0 ? 1 : num2;
                            while (num2 >= 0)
                            {
                                int count1 = count;
                                Vector3Int parallelEdgePos = edgePos + paveDirVector * pavementWidth * num2;
                                
                                //Vector3Int parallelEdgePos2 = parallelEdgePos;
                                while (count1 > 0)
                                {
                                    Vector3Int parallelEdgePos2 = parallelEdgePos - d * (count1 - 1) * pavementLength;
                                    if (num2 == 0)
                                    {
                                        if (!positions.ContainsKey(parallelEdgePos2) || blockedPositions.Contains(parallelEdgePos2))
                                        {
                                            tempBlocked.Clear();
                                            avaliable = false;
                                            break;
                                        }
                                    }
                                    else
                                    {
                                        if (positions.ContainsKey(parallelEdgePos2) || blockedPositions.Contains(parallelEdgePos2))
                                        {
                                            // blockedPositions.AddRange(tempBlocked);
                                            tempBlocked.Clear();
                                            avaliable = false;
                                            break;
                                        }
                                    }
                                    tempBlocked.Add(parallelEdgePos2);

                                    count1--;
                                }

                                if (!avaliable)
                                {
                                    break;
                                }

                                num2--;
                            }
                            
                            if (!avaliable)
                            {
                                break;
                            }

                            int num3 = Mathf.CeilToInt(buildType.width / pavementLength);
                            num3 = num3 <= 0 ? 1 : num3;
                            Vector3Int verticalEdgePos = edgePos + (pavementLength - pavementWidth) * d / 2 + (pavementLength - pavementWidth) * paveDirVector / 2;
                            
                            while (num3 > 0)
                            {                          
                                Vector3Int verticalEdgePos2 = verticalEdgePos;
                                verticalEdgePos += paveDirVector * pavementLength;
                                int count2 = Mathf.FloorToInt(Mathf.CeilToInt(buildType.distance / pavementWidth) / 2);
                                while (count2 > 0)
                                {                                  
                                    if (positions.ContainsKey(verticalEdgePos2) || blockedPositions.Contains(verticalEdgePos2))
                                    {
                                        tempBlocked.Clear();
                                        avaliable = false;
                                        break;
                                    }
                                    else
                                    {
                                        tempBlocked.Add(verticalEdgePos2);
                                    }
                                    verticalEdgePos2 -= d * pavementWidth;
                                    count2--;
                                }
                                if (!avaliable)
                                {
                                    break;
                                }
                                num3--;
                            }
                            if (!avaliable)
                            {
                                break;
                            }
                        }

                        if(tempBlocked.Count > 0)
                        {
                            blockedPositions.AddRange(tempBlocked);
                            tempBlocked.Clear();
                        }
                        if (avaliable)
                        {                            
                            int index = Random.Range(0, buildType.prefabs.Count);
                            Transform parent = buildType.structureType == StructureType.Nautre ? natureParent.transform : buildParent.transform;
                            GameObject buildObject = Instantiate(buildType.prefabs[index], parent);
                           
                            Vector3Int pos = PlacementMgr.GetDirectionVector3(info.Value) * ((pavementWidth + buildType.width) / 2) + info.Key;
                            if (!buildDic.ContainsKey(pos))
                            {
                                float eulerY = buildObject.transform.rotation.eulerAngles.y;
                                Quaternion rotation = Quaternion.identity;
                                Direction d = PlacementMgr.GetReverseDirection(info.Value);
                                switch (d)
                                {
                                    case Direction.Up:
                                        rotation = Quaternion.Euler(0, eulerY - 90, 0);
                                        break;
                                    case Direction.Down:
                                        rotation = Quaternion.Euler(0, eulerY + 90, 0);
                                        break;
                                    case Direction.Left:
                                        rotation = Quaternion.Euler(0, eulerY + 180, 0);
                                        break;
                                    case Direction.Right:
                                        rotation = Quaternion.Euler(0, eulerY, 0);
                                        break;
                                }
                                buildObject.transform.SetPositionAndRotation(pos, rotation);
                                buildDic.Add(pos, buildObject);
                                buildDirectionDic.Add(pos, d);
                                blockedPositions.Add(info.Key);
                            }
                            
                        }

                    }
                }
                else
                {
                    if (!blockedPositions.Contains(info.Key))
                    {
                        blockedPositions.Add(info.Key);
                    }
                   
                }
                if (GameState.Instance.requiredAnimation)
                {
                    yield return new WaitForSeconds(animationTime);
                }
               
            }
            waitingForBuilding = false;
        }

        public void reset()
        {
            foreach(var o in buildDic)
            {
                Destroy(o.Value);
            }
            buildDic.Clear();
            buildDirectionDic.Clear();
        }

    }
}
