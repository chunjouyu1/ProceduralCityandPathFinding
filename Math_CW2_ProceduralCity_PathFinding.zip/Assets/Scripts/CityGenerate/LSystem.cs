﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Linq;
using System.Text;
using System;
using Singleton;


namespace CityGenerate
{
    public struct TurtleData
    {
        public string axiom;
        public string roadSymbol;
        //public char? buildingSymbol;
        //public char? treeSymbol;      
        public string[] rules;
        public int interation;
        public bool randomRule;
        public float ignoreRuleChance;
        public float mainRoadChance;
        public int roadSize;
        public int pavementWidth;
        public float angle;
        public int maxLength;
        public int minLength;
        public float zebraChance;
        public int zebraMaxNumOneRoad;

        /*
        public TurtleData(string ax = "", string ds = "F", string rs = "", int it = 0, bool randomR = false, float ignoreChance = 0, float mainChance = 0, int rl = 0, int pl = 0, float ag = 0, int maxL = 0, int minL = 0, float zc = 0, int zn = 0)
        {
            axiom = ax;
            roadSymbol = ds;
           // buildingSymbol = ls;
            //treeSymbol = fs;                 
            rules = rs.Split(';');
            interation = it;
            randomRule = randomR;
            ignoreRuleChance = ignoreChance;
            mainRoadChance = mainChance;
            roadSize = rl;
            pavementSize = pl;
            angle = ag;
            maxLength = maxL;
            minLength = minL;
            zebraChance = zc;
            zebraMaxNumOneRoad = zn;
        }*/
    }

    public class LSystem
    {
  
        public TurtleData curTurtleData { get { return _curTurtleData; } }
        private TurtleData _curTurtleData;

     
        private Dictionary<int, TurtleData> dataDic; 
        private string _curSentence;

        
      

        public string getNewSentence()
        {
            if(dataDic == null || dataDic.Count == 0)
            {
                TextAsset file = Resources.Load<TextAsset>("Files/Rules");
                FileParser.ParseRules(file.text, out dataDic);
            }
            if(GameState.Instance.preSceneName != GameState.Instance.curSceneName)
            {
                _curTurtleData = dataDic[GameState.Instance.curSceneId];
            }
        
           
            bool randomRule = _curTurtleData.randomRule;
            int iteration = _curTurtleData.interation;
            string roadSymbol = _curTurtleData.roadSymbol;
            _curSentence = _curTurtleData.axiom;
            float ignoreRuleChance = _curTurtleData.ignoreRuleChance;

            Dictionary<char, string> rules = new Dictionary<char, string>();
            if (!randomRule)
            {
                for (int i = 0; i < _curTurtleData.rules.Length; i++)
                {
                    string[] _rule = _curTurtleData.rules[i].Split('=');
                    if (_rule.Length >= 2)
                    {
                        char key = Convert.ToChar(_rule[0].Trim());
                        if (rules.ContainsKey(key))
                        {
                            rules[key] = _rule[1].Trim();
                        }
                        else
                        {
                            rules.Add(key, _rule[1].Trim());
                        }

                    }
                }
            }

            StringBuilder nextGen = new StringBuilder();

            while (iteration > 0)
            {
                for (int i = 0; i < _curSentence.Length; i++)
                {
                    if (randomRule)
                    {
                        if (_curSentence[i].ToString() == roadSymbol)
                        {
                            int index = UnityEngine.Random.Range(0, _curTurtleData.rules.Length);
                            string v = _curTurtleData.rules[index];
                            if (v != null)
                            {
                                if(UnityEngine.Random.value < ignoreRuleChance)
                                {
                                    nextGen.Append(roadSymbol);
                                }
                                else
                                {
                                    nextGen.Append(v);
                                }
                                
                            }
                        }
                        else
                        {
                            nextGen.Append(_curSentence[i]);
                        }
                    }
                    else
                    {
                        if (rules.ContainsKey(_curSentence[i]))
                        {
                            string v = rules[_curSentence[i]];
                            if (v != null)
                            {
                                if (UnityEngine.Random.value < ignoreRuleChance)
                                {
                                    nextGen.Append(_curSentence[i]);
                                }
                                else
                                {
                                    nextGen.Append(v);
                                }
                                
                            }
                        }
                        else
                        {
                            nextGen.Append(_curSentence[i]);
                        }
                    }                   
                    
                }
                iteration--;             
                _curSentence = nextGen.ToString();
            }

            return _curSentence;
        }


    }
}
