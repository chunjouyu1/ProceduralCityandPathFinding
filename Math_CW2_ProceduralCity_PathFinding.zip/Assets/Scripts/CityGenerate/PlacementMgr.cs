﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

namespace CityGenerate
{

    public class PlacementMgr
    {
        public static List<Direction> FindNeighbourDirections(Vector3Int pos, ICollection<Vector3Int> collection, int size)
        {
            List<Direction> neighbourDirections = new List<Direction>();
            if(collection.Contains(pos + Vector3Int.right * size))
            {
                neighbourDirections.Add(Direction.Right);
            }
            if (collection.Contains(pos + Vector3Int.left * size))
            {
                neighbourDirections.Add(Direction.Left);
            }
            if (collection.Contains(pos + new Vector3Int(0, 0, 1) * size))
            {
                neighbourDirections.Add(Direction.Up);
            }
            if (collection.Contains(pos - new Vector3Int(0, 0, 1) * size))
            {
                neighbourDirections.Add(Direction.Down);
            }

            return neighbourDirections;
        }

        public static List<Vector3Int> FindNeighbourDirectionVectors3(Vector3Int pos, ICollection<Vector3Int> collection, int size)
        {
            List<Vector3Int> neighbourDirectionVetors3 = new List<Vector3Int>();
            if (collection.Contains(pos + Vector3Int.right * size))
            {
                neighbourDirectionVetors3.Add(Vector3Int.right);
            }
            if (collection.Contains(pos - Vector3Int.left * size))
            {
                neighbourDirectionVetors3.Add(Vector3Int.left);
            }
            if (collection.Contains(pos + new Vector3Int(0, 0, 1) * size))
            {
                neighbourDirectionVetors3.Add(new Vector3Int(0, 0, 1));
            }
            if (collection.Contains(pos - new Vector3Int(0, 0, 1) * size))
            {
                neighbourDirectionVetors3.Add(new Vector3Int(0, 0, -1));
            }

            return neighbourDirectionVetors3;
        }

        public static Vector3Int GetDirectionVector3(Direction d)
        {
            if(d == Direction.Down)
            {
                return new Vector3Int(0, 0, -1);
            }
            else if(d == Direction.Up)
            {
                return new Vector3Int(0, 0, 1);
            }
            else if (d == Direction.Right)
            {
                return Vector3Int.right;
            }
            else if(d == Direction.Left)
            {
                return Vector3Int.left;
            }
            else
            {
                throw new System.Exception("No such direction " + d);
            }
           
        }

        public static Direction GetReverseDirection(Direction d)
        {
            
            switch (d)
            {
                case Direction.Down:
                    d = Direction.Up;
                    break;
                case Direction.Up:
                    d = Direction.Down;
                    break;
                case Direction.Left:
                    d = Direction.Right;
                    break;
                case Direction.Right:
                    d = Direction.Left;
                    break;
            }
            return d;
        }

        public static List<Vector3Int> GetVerticalDirectionVectors3(Direction d)
        {
            List<Vector3Int> verticalDirections = new List<Vector3Int>();
            if (d == Direction.Down || d == Direction.Up)
            {
                verticalDirections.Add(Vector3Int.right);
                verticalDirections.Add(Vector3Int.left);
            }
            else if (d == Direction.Right || d == Direction.Left)
            {
                verticalDirections.Add(new Vector3Int(0, 0, 1));
                verticalDirections.Add(new Vector3Int(0, 0, -1));
            }
            else
            {
                throw new System.Exception("No such direction " + d);
            }
            return verticalDirections;
        }

       

        public static Dictionary<Vector3Int, Direction> GetAvaliablePositions(ICollection<Vector3Int> collection, int size, int needSize)
        {
            Dictionary<Vector3Int, Direction> freePositions = new Dictionary<Vector3Int, Direction>();
            foreach(var pos in collection)
            {
                 
                List<Direction> dirList = FindNeighbourDirections(pos, collection, size);
                foreach(Direction d in Enum.GetValues(typeof(Direction)))
                {
                    if (!dirList.Contains(d))
                    {
                        Vector3Int dirVector = GetDirectionVector3(d);                      
                        Vector3Int freePos = pos + dirVector * ((size + needSize) / 2);
                       
                        if (!freePositions.ContainsKey(freePos))
                        {
                            freePositions.Add(freePos, d);
                        }
                    }
                }
            }

            return freePositions;
        }

        public static Vector3 GetNeighbourScale(Vector3Int position, Direction direction, IDictionary<Vector3Int, GameObject> collection, int size)
        {                   
            if (direction == Direction.Down || direction == Direction.Up)
            {               
                Vector3Int neighbourPos = position + new Vector3Int(0, 0, 1) * size;
                if (collection.Keys.Contains(neighbourPos))
                {
                    return collection[neighbourPos].transform.localScale;
                }
                neighbourPos = position + new Vector3Int(0, 0, -1) * size;
                if (collection.Keys.Contains(neighbourPos))
                {
                    return collection[neighbourPos].transform.localScale;
                }
            }
            else if (direction == Direction.Right || direction == Direction.Left)
            {
                Vector3Int neighbourPos = position + Vector3Int.right * size;
                if (collection.Keys.Contains(neighbourPos))
                {
                    return collection[neighbourPos].transform.localScale;
                }
                neighbourPos = position + Vector3Int.left * size;
                if (collection.Keys.Contains(neighbourPos))
                {
                    return collection[neighbourPos].transform.localScale;
                }
            }
            return Vector3.one;
        }


    }

}