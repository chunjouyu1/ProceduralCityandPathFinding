﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Singleton;

public class CameraMove : SingleStaticInstance<CameraMove>
{
    private Vector3 minPoint;
    private Vector3 maxPoint;
    private float maxHeight;
    private float minHeight = 1;
    private bool canMove = false;

    private float zoomSpeed = 50f;
    private float moveTPSpeed = 60f;
    private float moveFPSpeed = 10f;
    private float rotateSpeed = 20f;
   
    private float maxRotateHeight = 10f;
  
    public void initMoveCamera(Vector3Int[] edgePoints)
    {
        if (edgePoints.Length < 2)
        {
            return;
        }
        minPoint = edgePoints[0];
        maxPoint = edgePoints[1];
        float disX = edgePoints[1].x - edgePoints[0].x;
        float disY = edgePoints[1].z - edgePoints[0].z;
        maxHeight = disX > disY ? disX : disY;
        maxHeight += minPoint.y;
        canMove = true;
    }

    public void resetMoveMainCamera()
    {
        canMove = false;
    }

    private void moveMainCamera()
    {
        Vector3 newPos = transform.position;
        Quaternion rotation = transform.rotation;
       
       
        if (Input.GetKey(KeyCode.Z))
        {
            newPos.y -= Time.deltaTime * zoomSpeed;
            newPos.y = newPos.y < minHeight ? minHeight : newPos.y;
            if (newPos.y <= minHeight && rotation != Quaternion.Euler(0, 0, 0))
            {
                float angle = Mathf.LerpAngle(rotation.eulerAngles.x, 0, Time.deltaTime * rotateSpeed);
            
                transform.rotation = Quaternion.Euler(angle, 0, 0);
               
            }
   
        }
        if (Input.GetKey(KeyCode.Q))
        {
            newPos.y += Time.deltaTime * zoomSpeed;
            newPos.y = newPos.y > maxHeight ? maxHeight : newPos.y;
            if (newPos.y >= maxRotateHeight && rotation != Quaternion.Euler(90, 0, 0))
            {
                float angle = Mathf.LerpAngle(rotation.eulerAngles.x, 90, Time.deltaTime * rotateSpeed);
                transform.rotation = Quaternion.Euler(angle, 0, 0);
         
            }
        }

        float inputHorizontal = Input.GetAxis("Horizontal");
        float inputVertical = Input.GetAxis("Vertical");
        if (inputHorizontal != 0)
        {
            
            if(newPos.y <= minHeight)
            {
                transform.RotateAround(transform.position, transform.up, inputHorizontal * Time.deltaTime * rotateSpeed);
            }
            else
            {
                newPos.x += inputHorizontal * moveTPSpeed * Time.deltaTime;
                newPos.x = newPos.x < minPoint.x ? minPoint.x : newPos.x;
                newPos.x = newPos.x > maxPoint.x ? maxPoint.x : newPos.x;
            }
        }
        if(inputVertical != 0)
        {
            
            if (newPos.y <= minHeight)
            {
               // Vector3 position = transform.position;
             //   Vector3 positionZ = transform.forward * moveFPSpeed * Time.deltaTime;
              //  newPos.z = positionZ.z;
                transform.Translate(Vector3.forward * moveFPSpeed * Time.deltaTime * inputVertical);
                newPos.y = 0;
                //transform.position = newPos;
            }
            else
            {
                newPos.z += inputVertical * moveTPSpeed * Time.deltaTime;
                newPos.z = newPos.z < minPoint.z ? minPoint.z : newPos.z;
                newPos.z = newPos.z > maxPoint.z ? maxPoint.z : newPos.z;
            }
            
        }
        if (newPos.y >= minHeight)
        {
            transform.position = newPos;
        }
           
       // transform.SetPositionAndRotation(newPos, rotation);
    }
  
    
    void Update()
    {
        if (!canMove)
            return;

        moveMainCamera();
    }
}
