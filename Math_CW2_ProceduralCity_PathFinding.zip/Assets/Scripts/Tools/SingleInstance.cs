﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Singleton
{
    public class SingleInstance<T> : MonoBehaviour where T : SingleInstance<T>
    {

        private static T instance;
        private static bool initialized = false;
        public static GameObject obj;

        public static T Instance
        {
            get
            {
                if (instance == null)
                {
                    // Debug.Log("there is singleinstance");
                    obj = GameObject.Find("DontDestroyGameObject");
                    if (!obj)
                    {
                        Initialize();
                    }

                    instance = obj.AddComponent<T>();
                }
                return instance;
            }
        }

        private static void Initialize()
        {
            if (!initialized)
            {
                //Debug.Log("Initialize");
                initialized = true;
                obj = new GameObject("DontDestroyGameObject");
                DontDestroyOnLoad(obj);
            }

        }

    }

}
