﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


namespace Singleton {
    public class SingleStaticInstance<T> : MonoBehaviour where T : SingleStaticInstance<T>
    {

        private static T m_Instance;
        public static T Instance
        {
            get
            {
                return m_Instance;
            }
        }

        private void OnEnable()
        {
            m_Instance = this as T;
        }

    }

}
