﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
using CityGenerate;

public static class FileParser
{

    public static void ParseRules(string content, out Dictionary<int, TurtleData> ruleDic)
    {

        ruleDic = new Dictionary<int, TurtleData>();

        var datas = content.Split('}');
        foreach (string rawData in datas)
        {
            int key = -1;
            TurtleData td = new TurtleData();

            var lines = rawData.Split('\n');
            foreach (string rawLine in lines)
            {
                string line = rawLine.Trim();
                if (line == "{")
                    continue;
                if (line.Length == 0)
                    continue;
                else if (line.Length == 1 && line[0] == '\r')
                    continue;
                else if (line[0] == '/' && line[1] == '/')
                    continue;
                string value;


                if (line.IndexOf("sceneId") != -1)
                {
                    value = line.Substring(line.IndexOf("=") + 1);
                    value = value.Trim();
                    key = Convert.ToInt32(value);

                }
                else if (line.IndexOf("roadSymbol") != -1)
                {
                    value = line.Substring(line.IndexOf("=") + 1);
                    value = value.Trim();
                    td.roadSymbol = value;
                }
                else if (line.IndexOf("randomRule") != -1)
                {
                    value = line.Substring(line.IndexOf("=") + 1);
                    value = value.Trim();
                    td.randomRule = value == "true";
                }
                else if (line.IndexOf("ignoreRuleChance") != -1)
                {
                    value = line.Substring(line.IndexOf("=") + 1);
                    value = value.Trim();
                    td.ignoreRuleChance = float.Parse(value);
                }
                else if (line.IndexOf("mainRoadChance") != -1)
                {
                    value = line.Substring(line.IndexOf("=") + 1);
                    value = value.Trim();
                    td.mainRoadChance = float.Parse(value);
                }
                else if (line.IndexOf("zebraChance") != -1)
                {
                    value = line.Substring(line.IndexOf("=") + 1);
                    value = value.Trim();
                    td.zebraChance = float.Parse(value);
                }
                else if (line.IndexOf("zebraMaxNumOneRoad") != -1)
                {
                    value = line.Substring(line.IndexOf("=") + 1);
                    value = value.Trim();
                    td.zebraMaxNumOneRoad = Convert.ToInt32(value);
                }
                else if (line.IndexOf("axiom") != -1)
                {
                    value = line.Substring(line.IndexOf("=") + 1);
                    value = value.Trim();
                    td.axiom = value;
                }
                else if (line.IndexOf("angle") != -1)
                {
                    value = line.Substring(line.IndexOf("=") + 1);
                    value = value.Trim();
                    td.angle = float.Parse(value);
                }
                else if (line.IndexOf("rules") != -1)
                {
                    value = line.Substring(line.IndexOf(":") + 1);
                    value = value.Trim();
                    td.rules = value.Split(';');
                }
                else if (line.IndexOf("interation") != -1)
                {
                    value = line.Substring(line.IndexOf("=") + 1);
                    value = value.Trim();
                    td.interation = Convert.ToInt32(value);
                }
                else if (line.IndexOf("roadSize") != -1)
                {
                    value = line.Substring(line.IndexOf("=") + 1);
                    value = value.Trim();
                    td.roadSize = Convert.ToInt32(value);
                }
                else if (line.IndexOf("pavementWidth") != -1)
                {
                    value = line.Substring(line.IndexOf("=") + 1);
                    value = value.Trim();
                    td.pavementWidth = Convert.ToInt32(value);
                }
                else if (line.IndexOf("maxLength") != -1)
                {
                    value = line.Substring(line.IndexOf("=") + 1);
                    value = value.Trim();
                    td.maxLength = Convert.ToInt32(value);
                }
                else if (line.IndexOf("minLength") != -1)
                {
                    value = line.Substring(line.IndexOf("=") + 1);
                    value = value.Trim();
                    td.minLength = Convert.ToInt32(value);
                }
            }


            if (key >= 0 && !ruleDic.ContainsKey(key))
            {
                ruleDic.Add(key, td);

            }
        }
    }


    public static void ParsePaths(string content, out Dictionary<string, string> pathDic)
    {

        pathDic = new Dictionary<string, string>();

        var lines = content.Split('\n');
        foreach (string rawLine in lines)
        {
            string line = rawLine.Trim();
            if (line.Length == 0)
                continue;
            else if (line.Length == 1 && line[0] == '\r')
                continue;
            else if (line[0] == '/' && line[1] == '/')
                continue;


            string[] str = line.Split('=');
            if (str.Length > 1)
            {
                pathDic.Add(str[0], str[1]);
            }

        }
    }

    public static void ParseSceneList(string content, out List<GameState.SceneInfo> sceneInfos)
    {

        sceneInfos = new List<GameState.SceneInfo>();

        var datas = content.Split('}');
        foreach (string rawData in datas)
        {
            GameState.SceneInfo info = new GameState.SceneInfo();
            info.id = -1;
            var lines = rawData.Split(';');
            foreach (string rawLine in lines)
            {
                string line = rawLine.Trim();
                if (line == "{")
                    continue;
                if (line.Length == 0)
                    continue;
                else if (line.Length == 1 && line[0] == '\r')
                    continue;
                else if (line[0] == '/' && line[1] == '/')
                    continue;
                string value;


                if (line.IndexOf("sceneId") != -1)
                {
                    value = line.Substring(line.IndexOf("=") + 1);
                    value = value.Trim();
                    info.id = Convert.ToInt32(value);

                }
                else if (line.IndexOf("name") != -1)
                {
                    value = line.Substring(line.IndexOf("=") + 1);
                    value = value.Trim();
                    info.name = value;
                }
                else if (line.IndexOf("natureChance") != -1)
                {
                    value = line.Substring(line.IndexOf("=") + 1);
                    value = value.Trim();
                    info.natureChance = float.Parse(value);
                }
                else if (line.IndexOf("imagePath") != -1)
                {
                    value = line.Substring(line.IndexOf("=") + 1);
                    value = value.Trim();
                    info.imagePath = value;
                }
                else if (line.IndexOf("skyboxPath") != -1)
                {
                    value = line.Substring(line.IndexOf("=") + 1);
                    value = value.Trim();
                    info.skyboxPath = value;
                }
            }
            if(info.id > -1)
            {
                sceneInfos.Add(info);
            }
            
        }
    }

    public static void ParseBuildingType(string content, out Dictionary<int, List<BuildingType>> buildingDic)
    {
        buildingDic = new Dictionary<int, List<BuildingType>>();

        var datas = content.Split('}');
        foreach (string rawData in datas)
        {
            int key = -1;
            BuildingType td = new BuildingType();

            var lines = rawData.Split('\n');
            foreach (string rawLine in lines)
            {
                string line = rawLine.Trim();
                if (line == "{")
                    continue;
                if (line.Length == 0)
                    continue;
                else if (line.Length == 1 && line[0] == '\r')
                    continue;
                else if (line[0] == '/' && line[1] == '/')
                    continue;
                string value;


                if (line.IndexOf("sceneId") != -1)
                {
                    value = line.Substring(line.IndexOf("=") + 1);
                    value = value.Trim();
                    key = Convert.ToInt32(value);

                }
                else if (line.IndexOf("buildingType") != -1)
                {
                    value = line.Substring(line.IndexOf("=") + 1);
                    value = value.Trim();
                    td.type = Convert.ToInt32(value);
                }
                else if (line.IndexOf("width") != -1)
                {
                    value = line.Substring(line.IndexOf("=") + 1);
                    value = value.Trim();
                    td.width = Convert.ToInt32(value);
                }
                else if (line.IndexOf("distance") != -1)
                {
                    value = line.Substring(line.IndexOf("=") + 1);
                    value = value.Trim();
                    td.distance = Convert.ToInt32(value);
                }
                else if (line.IndexOf("maxCount") != -1)
                {
                    value = line.Substring(line.IndexOf("=") + 1);
                    value = value.Trim();
                    td.maxCount = Convert.ToInt32(value);
                }
                else if (line.IndexOf("chance") != -1)
                {
                    value = line.Substring(line.IndexOf("=") + 1);
                    value = value.Trim();
                    td.chance = float.Parse(value);
                }
                else if (line.IndexOf("path") != -1)
                {
                    value = line.Substring(line.IndexOf("=") + 1);
                    value = value.Trim();
                    td.paths.Add(value);
                }
                
            }


            if (key >= 0)
            {
                if (!buildingDic.ContainsKey(key))
                {
                    List<BuildingType> list = new List<BuildingType>();
                    buildingDic.Add(key, list);
                }
                buildingDic[key].Add(td);
            }
        }
    }


}
