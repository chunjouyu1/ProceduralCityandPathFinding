﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using Singleton;

public class UIcontroller : SingleStaticInstance<UIcontroller>
{
   public GameObject pnlChooseCity;
    public Animator ChooseCity_animator;
    public GameObject pnlMain;
    public GameObject pnlGame;
    public GameObject scrollContent;
    private GameObject cityContentItem;
    public GameObject AppearAfterGenerate;
    public GameObject generatingPnl;
    public Text CityTitle;
    public Text CityTitle1;
    public GameObject btnOverView;
    public GameObject btnCarView;

    private void Start()
    {
        pnlChooseCity.SetActive(false);
        ChooseCity_animator.SetBool("open", false);
        ChooseCity_animator.SetBool("close", false);
    }

  

    public void showGamePnl()
    {
        if (pnlMain.activeSelf)
        {
            pnlMain.SetActive(false);
        }
        if (!pnlGame.activeSelf)
        {
            pnlGame.SetActive(true);
        }
        if (GameState.Instance.curState == GameState.State.Loading && AppearAfterGenerate.activeSelf)
        {
            AppearAfterGenerate.SetActive(false);
            generatingPnl.SetActive(true);
        }
        if (GameState.Instance.curState == GameState.State.Game && !AppearAfterGenerate.activeSelf)
        {
            AppearAfterGenerate.SetActive(true);
            generatingPnl.SetActive(false);
        }
    }

    public void showMainPnl()
    {
        if (!pnlMain.activeSelf)
        {
            pnlMain.SetActive(true);
        }
        if (pnlGame.activeSelf)
        {
            pnlGame.SetActive(false);
        }
    }

    public void enableCarView()
    {
        if (!btnCarView.activeSelf)
        {
            btnCarView.SetActive(true);
        }
        if (btnOverView.activeSelf)
        {
            btnOverView.SetActive(false);
        }
       
    }

    public void enableOverView()
    {
        if (btnCarView.activeSelf)
        {
            btnCarView.SetActive(false);
        }
        if (!btnOverView.activeSelf)
        {
            btnOverView.SetActive(true);
        }

    }


    public void bringupMenu()
    {
        pnlChooseCity.SetActive(true);
        ChooseCity_animator.SetBool("open", true);
        ChooseCity_animator.SetBool("close", false);

        if (scrollContent.transform.childCount <= 0)
        {
            int count = GameMgr.Instance.sceneList.Count;
            for (int i = 0; i < count; i++)
            {
                GameState.SceneInfo info = GameMgr.Instance.sceneList[i];
                
                if (!cityContentItem)
                {
                    cityContentItem = Resources.Load<GameObject>("Prefabs/CityPic");

                }
                GameObject item = Instantiate(cityContentItem, scrollContent.transform);
                item.GetComponent<Image>().sprite = Resources.Load<Sprite>(info.imagePath);
                Transform btnItem = item.transform.Find("CityBtn");
                if (!btnItem)
                {
                    continue;
                }
                btnItem.Find("Text1").GetComponent<Text>().text = info.name;
                btnItem.Find("Text").GetComponent<Text>().text = info.name;
                int index = i;
                btnItem.GetComponent<Button>().onClick.AddListener(delegate ()
                {
                    resetMenu();
                    GameMgr.Instance.enterGame(index);
                    CityTitle.text = GameState.Instance.curSceneName;
                    CityTitle1.text = GameState.Instance.curSceneName;
                });
            }
        }
       
    }

    public void closeMenu()
    {
        //pnlChooseCity.SetActive(false);
        ChooseCity_animator.SetBool("open", false);
        ChooseCity_animator.SetBool("close", true);
    }
    
    public void resetMenu()
    {
        pnlChooseCity.SetActive(false);
    }

}
