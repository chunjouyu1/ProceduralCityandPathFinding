﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WorldTargetGeneration : MonoBehaviour
{
    public List<GameObject> units;
    public List<GameObject> characterPrefabs;
    public List<GameObject> characters;
    public int loopTime;
    public GameObject Characters;
    Transform targetTransform;
    public Vector3 transformOffset;
    private void Awake()
    {
        units = new List<GameObject>();
        characters = new List<GameObject>();
    }
    public void GetNewTarget(Unit unit)
    {
        unit.target = GetTargetTransform(unit);
        Debug.Log(unit.target);
    }
    private Transform GetTargetTransform(Unit characterUnit)
    {
        targetTransform = units[Random.Range(0, units.Count-1)].transform;
        return targetTransform;
    }
    private Vector3 GetSpawnPos() 
    { 
        Vector3 pos = units[Random.Range(0, units.Count - 1)].transform.position;
        pos.y = 0;
        //Debug.Log(pos);
        return pos;
    }
    public void GenerateCharacters()
    {
        while(loopTime!=0&&units!=null)
        {
            GameObject character =Instantiate(
                characterPrefabs[Random.Range(0, characterPrefabs.Count-1)], 
                GetSpawnPos(), 
                Quaternion.identity);
            characters.Add(character);
            character.transform.SetParent(Characters.transform);
            character.GetComponent<Unit>().target = GetTargetTransform(character.GetComponent<Unit>());
            loopTime--;
        }
    }

}
