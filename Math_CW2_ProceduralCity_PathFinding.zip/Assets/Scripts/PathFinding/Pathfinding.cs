﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

public class Pathfinding : MonoBehaviour
{
    //point is to find the lowest F cost
    GridTesting grid;
    //public Transform seeker, target; only for testing before using queue

    private void Awake()
    {
        grid = GetComponent<GridTesting>();
    }
    public void FindPath(PathRequest request, Action<PathResult> callback)
    {
        Vector3[] waypoints = new Vector3[0];
        bool pathSuccess = false;

        Node startNode = grid.NodeFromWorldPoint(request.pathStart);
        Node targetNode = grid.NodeFromWorldPoint(request.pathEnd);
        startNode.parent = startNode;

        if (startNode.walkable && targetNode.walkable)
        {
            //List<Node> openSet = new List<Node>(); old method, long search time, discard
            Heap<Node> openSet = new Heap<Node>(grid.MaxSize);
            HashSet<Node> closeSet = new HashSet<Node>();
            openSet.Add(startNode);

            while (openSet.Count > 0)
            {

                /*old method, long search time, discard
                Node currentNode = openSet[0];
                for(int i = 1; i<openSet.Count; i++)
                {
                    if(openSet[i].fCost<currentNode.fCost||openSet[i].fCost == currentNode.fCost &&openSet[i].hCost<currentNode.hCost)
                    {
                        currentNode = openSet[i];
                    }
                }
                openSet.Remove(currentNode);
                */
                Node currentNode = openSet.RemoveFirst();
                closeSet.Add(currentNode);
                if (currentNode == targetNode) // end of searching, found the path
                {
                    pathSuccess = true;
                    break;
                }
                foreach (Node neightbour in grid.GetNeighbours(currentNode))
                {
                    if (!neightbour.walkable || closeSet.Contains(neightbour))
                    {
                        continue;
                    }
                    int newMovementCostToNeighbour = currentNode.gCost + GetDistance(currentNode, neightbour) + neightbour.movementPenalty;
                    if (newMovementCostToNeighbour < neightbour.gCost || !openSet.Contains(neightbour))
                    {
                        neightbour.gCost = newMovementCostToNeighbour;
                        neightbour.hCost = GetDistance(neightbour, targetNode);
                        neightbour.parent = currentNode;
                        if (!openSet.Contains(neightbour))
                        {
                            openSet.Add(neightbour);
                        }else
                        {
                            openSet.UpdateItem(neightbour);
                        }
                    }
                }
            }
        }
        if (pathSuccess)
        {
            waypoints = RetracePath(startNode, targetNode);
            pathSuccess = waypoints.Length > 0;
        }
        callback(new PathResult(waypoints, pathSuccess, request.callback));
    }
    Vector3[] RetracePath(Node startNode, Node endNode)
    {
        List<Node> path = new List<Node>();
        Node currentNode = endNode;
        while (currentNode != startNode)
        {
            path.Add(currentNode);
            currentNode = currentNode.parent;
        }
        //before calling reverse, need to call simplify first 
        Vector3[] waypoints = SimplefyPath(path);
        //then reverse the waypoints
        //path.Reverse();
        Array.Reverse(waypoints);
        //grid.path = path; not going to display grid anymore, only for testing
        return waypoints;
    }

    Vector3[] SimplefyPath(List<Node> path)
    {
        List<Vector3> waypoints = new List<Vector3>();
        //to store the direction of the last two nodes
        Vector2 directionOld = Vector2.zero;

        for(int i =1; i<path.Count; i++)
        {
            Vector2 directionNew = new Vector2(path[i - 1].gridX - path[i].gridX, path[i - 1].gridY - path[i].gridY);
            if(directionNew != directionOld)
            {
                waypoints.Add(path[i].worldPosition);
            }
            directionOld = directionNew;
        }
        return waypoints.ToArray();
    }


    int GetDistance(Node nodeA, Node nodeB)
    {
        int dstX = Mathf.Abs(nodeA.gridX - nodeB.gridX);
        int dstY = Mathf.Abs(nodeA.gridY - nodeB.gridY);


        //if the dstX is bigger, means after first move diagonal, horizontal distance will be calculated. diagonal distance will times 14.
        if(dstX>dstY)
        {
            return 14 * dstY + 10 * (dstX - dstY);
        }else
        {
            return 14 * dstX + 10 * (dstY - dstX);
        }
    }


}
