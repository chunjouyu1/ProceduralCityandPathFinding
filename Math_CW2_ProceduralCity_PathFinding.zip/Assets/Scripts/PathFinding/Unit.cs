﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Unit : MonoBehaviour
{
	const float minPathUpdateTime = .2f;
	const float pathUpdateMoveThreshold = .5f;

	public WorldTargetGeneration wtg;
	public Transform target;
    [Range(0,100)]
    public float speed = 1.5f;
    Path path;
	public float stoppingDst = 2;
	public float turnSpeed = 50;
	public float turnDst = 1;

    private void Start()
    {
		wtg = GameObject.Find("WTG").GetComponent<WorldTargetGeneration>();
		StartCoroutine(UpdatePath());
	}
    public void OnPathFound(Vector3[] waypoints, bool pathSuccessful)
	{
		if (pathSuccessful)
		{
			path = new Path(waypoints, transform.position, turnDst, stoppingDst);
			StopCoroutine("FollowPath");
			StartCoroutine("FollowPath");
		}
	}
	IEnumerator UpdatePath()
	{
		//this part suppose to update the path each frame
		if (Time.timeSinceLevelLoad < .3f)
		{
			yield return new WaitForSeconds(.3f);
		}
		PathRequestManager.RequestPath(new PathRequest(transform.position, target.position+new Vector3(0,0.5f,0), OnPathFound));
		float sqrMoveThreshold = pathUpdateMoveThreshold * pathUpdateMoveThreshold;
		Vector3 targetPosOld = target.position + new Vector3(0, 0.5f, 0);

		while (true)
		{
			yield return new WaitForSeconds(minPathUpdateTime);
			if ((target.position + new Vector3(0, 0.5f, 0) - targetPosOld).sqrMagnitude > sqrMoveThreshold)
			{
				PathRequestManager.RequestPath(new PathRequest(transform.position, target.position + new Vector3(0, 0.5f, 0), OnPathFound));
				targetPosOld = target.position + new Vector3(0, 0.5f, 0);
			}
		}
	}
	IEnumerator FollowPath()
	{
		bool followingPath = true;
		int pathIndex = 0;

		// to look at the first point in the path
		transform.LookAt(path.lookPoints[0]);

		float speedPercent = 1;

		while (followingPath)
		{
			// to constantly check if te object passed the turn boundary
			Vector2 pos2D = new Vector2(transform.position.x, transform.position.z);
			while (path.turnBoundaries[pathIndex].HasCrossedLine(pos2D))
			{
				if (pathIndex == path.finishLineIndex) // last index of the path, just in front of the dst
				{
					followingPath = false;
					break;
				}
				else
				{
					pathIndex++;
				}
			}

			if (followingPath)
			{

				if (pathIndex >= path.slowDownIndex && stoppingDst > 0)
				{
					speedPercent = Mathf.Clamp01(path.turnBoundaries[path.finishLineIndex].DistanceFromPoint(pos2D) / stoppingDst);
					if (speedPercent < 0.2f)
					{
						wtg.GetNewTarget(this);
						Debug.Log("Passed");
						followingPath = false;
					}
				}
				// do the rotation
				Quaternion targetRotation = Quaternion.LookRotation(path.lookPoints[pathIndex] - transform.position);
				transform.rotation = Quaternion.Lerp(transform.rotation, targetRotation, Time.deltaTime * turnSpeed);
				transform.Translate(Vector3.forward * Time.deltaTime * speed * speedPercent, Space.Self);
			}

			yield return null;

		}
	}

	public void OnDrawGizmos()
	{
		if (path != null)
		{
			path.DrawWithGizmos();
		}
	}
}
