﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PavementSpawnUnit : MonoBehaviour
{
    private WorldTargetGeneration wtg;

    private void Start()
    {
       wtg = GameObject.Find("WTG").GetComponent<WorldTargetGeneration>();
       wtg.units.Add(this.gameObject);
    }
}
