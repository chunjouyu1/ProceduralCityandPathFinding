﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using CityGenerate;

public class CarViewSwitcher : MonoBehaviour
{
   
    private GridTesting GD;
   

   
    public void EnableCar()
    {
        /*
        if (SceneManager.GetSceneByName("City 1").isLoaded)
        {
            GD = SceneManager.GetSceneByName("City 1").GetRootGameObjects()[1].GetComponent<GridTesting>();
            GD.SpawnCar();
        }
        else if (SceneManager.GetSceneByName("City 2").isLoaded)
        {
            GD = SceneManager.GetSceneByName("City 2").GetRootGameObjects()[1].GetComponent<GridTesting>();
            GD.SpawnCar();
        }*/
        GD = SceneManager.GetSceneByName(GameState.Instance.curSceneName).GetRootGameObjects()[1].GetComponent<GridTesting>();
        GD.SpawnCar();

        GameState.Instance.setCurGameState(GameState.State.CarGame);
    }

    

    public void DisableCar()
    {
        GameObject[] obj = SceneManager.GetSceneByName(GameState.Instance.curSceneName).GetRootGameObjects();
        for(int i = 0; i < obj.Length; i++)
        {
            if(obj[i].name=="A*")
            {
                GD = obj[i].GetComponent<GridTesting>();
                break;
            }
        }

        GameState.Instance.setCurGameState(GameState.State.Game);
        GD.DisableCar();
      
    }

}
