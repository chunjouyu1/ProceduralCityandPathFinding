﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class cam : MonoBehaviour
{
    public GameObject Player;
    public float followSpeed;
    private CarController carController;
    public Transform car;
    public GameObject[] looktarget;
    public GameObject[] camPos;
    private Camera carCam;
    public float defaultFov, targetFov;
    public float smoothTime;
    public Skybox skybox;

    public enum camState
    {
        positionBack,
        positionFront,
        positionTop,
        lookBack
        
    }
    public camState cameraState;
    private camState previousState;

    private void Awake()
    {
        carCam = this.GetComponent<Camera>();
        //Player = GameObject.FindGameObjectWithTag("Player");
        cameraState = camState.positionBack;
        carController = Player.GetComponent<CarController>();
        defaultFov = carCam.fieldOfView;
    }

    
    private void Start()
    {
        this.transform.position= camPos[0].transform.position;
        this.transform.LookAt(looktarget[0].gameObject.transform.position);
    }
    private void Update()
    {
        camSwitch();
    }
    private void FixedUpdate()
    {
        camFollow();
    }

    public void changeSkybox()
    {
        
        if (skybox)
        {
            string path = GameMgr.Instance.sceneList[GameState.Instance.curSceneId].skyboxPath;
            if (path != null && path != "")
            {
                Material material = Resources.Load<Material>(path);
                skybox.material = material;
            }        
        }
    }
    

    private void camFollow()
    {
        if(cameraState == camState.positionBack)
        {
            if(Input.GetKey(KeyCode.LeftShift))
            {
                carCam.fieldOfView = Mathf.Lerp(carCam.fieldOfView, targetFov, Time.deltaTime * smoothTime);
            }else
            {
                carCam.fieldOfView = Mathf.Lerp(carCam.fieldOfView, defaultFov, Time.deltaTime * smoothTime);
            }
            followSpeed =Mathf.Lerp(followSpeed, carController.KPH / 4, Time.deltaTime);
            this.transform.position = Vector3.Lerp(
                this.transform.position, 
                camPos[0].transform.position, 
                Time.deltaTime * followSpeed);
            this.transform.LookAt(looktarget[0].gameObject.transform.position);
            
        }
        else if(cameraState == camState.positionFront)
        {
            carCam.fieldOfView = defaultFov;
            this.transform.position = camPos[1].transform.position;
            this.transform.parent = camPos[1].transform;
            this.transform.LookAt(looktarget[1].gameObject.transform.position);
        }else if(cameraState == camState.positionTop)
        {
            carCam.fieldOfView = defaultFov;
            this.transform.position = camPos[2].transform.position;
            this.transform.parent = camPos[2].transform;
            this.transform.LookAt(looktarget[2].gameObject.transform.position);
        }else if (cameraState == camState.lookBack)
        {
            carCam.fieldOfView = defaultFov;
            this.transform.position = camPos[3].transform.position;
            this.transform.parent = camPos[3].transform;
            this.transform.LookAt(looktarget[3].gameObject.transform.position);
        }

    }


    private void camSwitch()
    {
        switch (cameraState)
        {
            case camState.positionBack:
                //this.transform.position = Vector3.Lerp(this.transform.position, camPos[0].transform.position, Time.deltaTime * followSpeed);
                //this.transform.LookAt(looktarget[0].gameObject.transform.position);
                if(Input.GetKeyDown(KeyCode.V))
                {
                    cameraState = camState.positionFront;
                }
                if (Input.GetKey(KeyCode.B))
                {
                    cameraState = camState.lookBack;
                    previousState = camState.positionBack;
                    //this.transform.parent = null;
                }
                break;
            case camState.positionFront:
                //this.transform.position = Vector3.Lerp(this.transform.position, camPos[1].transform.position, Time.deltaTime * followSpeed);
                //this.transform.LookAt(looktarget[1].gameObject.transform.position);
                if (Input.GetKeyDown(KeyCode.V))
                {
                    cameraState = camState.positionTop;
                    this.transform.parent = car;
                }
                if (Input.GetKey(KeyCode.B))
                {
                    cameraState = camState.lookBack;
                    previousState = camState.positionFront;
                    //this.transform.parent = null;
                }
                break;
            case camState.positionTop:
                //this.transform.position = Vector3.Lerp(this.transform.position, camPos[2].transform.position, Time.deltaTime * followSpeed);
                //this.transform.LookAt(looktarget[2].gameObject.transform.position);
                if (Input.GetKeyDown(KeyCode.V))
                {
                    cameraState = camState.positionBack;
                    this.transform.parent = car;
                }
                if (Input.GetKey(KeyCode.B))
                {
                    cameraState = camState.lookBack;
                    previousState = camState.positionTop;
                    //this.transform.parent = null;
                }
                break;
            case camState.lookBack:

                if(Input.GetKeyUp(KeyCode.B))
                {
                    cameraState = previousState;
                    this.transform.parent = car;
                }
                break;
        }
    }
}
