﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayCarsound : MonoBehaviour
{
    public CarSound carSound;
    public InputManager inputManager;
    public CarController carRB;
    private AudioSource source;
    private bool locker = false;
    private void Awake()
    {
        source = this.GetComponent<AudioSource>();
        source.clip = carSound.engineSound[0];
        if(source.enabled == true)
        {
            source.Play();
        }
        
    }

    private void Update()
    {
        source.pitch = (carRB.KPH / 220)+1;
        

    }

    
}
