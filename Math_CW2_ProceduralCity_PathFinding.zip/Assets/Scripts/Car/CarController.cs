﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CarController : MonoBehaviour
{
    public bool locker = false;
    internal enum driveType    //other place can access but cannot change the value
    {
        frontWheelDrive,
        rearWheelDrive,
        allWheelDrive
    }
    [SerializeField] private driveType drive;

    public List<WheelCollider> wheels = new List<WheelCollider>();
    public List<GameObject> wheelsMesh = new List<GameObject>();
    
    public float radius; //the radius for the ACKERMAN STEERING
    public GameObject centerMass; //letting the car stick to the ground and not flipping

    private Rigidbody carRB;
    public float KPH;
    public float torque;
    public float steeringPower;
    public float DownForceValue;
    public float brakePower;
    public float thrust; //boost force
    private InputManager inputManager;

    public GameObject car; // to reset the car;
    public Vector3 resetPos;


    public float[] slip = new float[4];

    private void Start()
    {
        inputManager = this.GetComponent<InputManager>();
        carRB = this.GetComponent<Rigidbody>();
        //centerMass = GameObject.Find("MassCenter");
        carRB.centerOfMass = centerMass.transform.localPosition;
    }
    private void FixedUpdate()
    {
        if(locker == true)
        {
            WheelRotate();
            MoveVehicle();
            TurnSteering();
            addDownForce();
            getFriction();
        }
        
    }
    
    private void MoveVehicle()
    {

        if(drive == driveType.allWheelDrive)
        {
            foreach (WheelCollider wheel in wheels)
            {
                wheel.motorTorque =inputManager.verticalInput * (torque/4);
            }
        }else if(drive == driveType.rearWheelDrive)
        {
            wheels[2].motorTorque = inputManager.verticalInput * (torque/2);
            wheels[3].motorTorque = inputManager.verticalInput * (torque/2);
        }
        else if(drive == driveType.frontWheelDrive)
        {
            wheels[0].motorTorque = inputManager.verticalInput * (torque / 2);
            wheels[1].motorTorque = inputManager.verticalInput * (torque / 2);
        }

        KPH = carRB.velocity.magnitude * 3.6f;
        if (KPH > 220)
        {
            KPH = 220;
            carRB.velocity = Vector3.ClampMagnitude(carRB.velocity, 62);
        }

        if (inputManager.handbrake)
        {
            wheels[2].brakeTorque = wheels[3].brakeTorque = brakePower;
        }else
        {
            wheels[2].brakeTorque = wheels[3].brakeTorque =0;
        }
        
        if(inputManager.boost)
        {
            carRB.AddForce(transform.forward * thrust);
        }
        // my own
        if (inputManager.reset)
        {
            car.transform.position = resetPos;
            //car.transform.rotation = resetPos;
        }


    }
    private void TurnSteering()
    {
        //ACKERMAN STEERING is to fix the problem the car cannot turn back when the first turn is too much, the steer will be locked

        if(inputManager.horizontalInput >0)
        {
            wheels[0].steerAngle = Mathf.Rad2Deg * Mathf.Atan(2.55f / (radius + (1.5f / 2))) * inputManager.horizontalInput;
            wheels[1].steerAngle = Mathf.Rad2Deg * Mathf.Atan(2.55f / (radius - (1.5f / 2)))* inputManager.horizontalInput;

        }else if(inputManager.horizontalInput < 0)
        {
            wheels[0].steerAngle = Mathf.Rad2Deg * Mathf.Atan(2.55f / (radius - (1.5f / 2))) * inputManager.horizontalInput;
            wheels[1].steerAngle = Mathf.Rad2Deg * Mathf.Atan(2.55f / (radius + (1.5f / 2))) * inputManager.horizontalInput;

        }
        else
        {
            wheels[0].steerAngle = 0;
            wheels[1].steerAngle = 0;
        }
    }

    private void WheelRotate()
    {
        Vector3 wheelsPosition = Vector3.zero;
        Quaternion wheelsRotation = Quaternion.identity;

        
        for(int i=0; i<wheels.Count; i++)
        {
            wheels[i].GetWorldPose(out wheelsPosition, out wheelsRotation);
            wheelsMesh[i].transform.position = wheelsPosition;
            wheelsMesh[i].transform.rotation = wheelsRotation;


        }


    }
    private void getFriction()
    {
        for (int i = 0; i < wheels.Count; i++)
        {
            //The way to simulate different ground materials is to query WheelCollider for its collision information 
            WheelHit wheelHit;
            /*
             * Gets ground collision data for the wheel.If the wheel collides with something, returns true and fills the hit structure. 
             * If the wheel is not colliding, returns false and leaves hit structure unchanged.
             */
            wheels[i].GetGroundHit(out wheelHit);
            slip[i] = wheelHit.sidewaysSlip; // returns the slip or the friction loss  "drifting"
        }
    }
    //to add force to the ground stick the car
    private void addDownForce()
    {
        carRB.AddForce(-transform.up * DownForceValue * carRB.velocity.magnitude);
    }
    //my own clearing function
    public void clearSpeed()
    {
        torque = 0;
        carRB.velocity = new Vector3(0, 0, 0);   
    }
}
