﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class InputManager : MonoBehaviour
{
    public float verticalInput;
    public float horizontalInput;
    public bool handbrake;
    public bool boost;
    public bool moving;
    public bool reset;
    

    private void Update()
    {
        verticalInput = Input.GetAxis("Vertical");
        horizontalInput = Input.GetAxis("Horizontal");
        handbrake = (Input.GetKey(KeyCode.Space))? true : false;
        boost = (Input.GetKey(KeyCode.LeftShift)) ? true : false;
        moving = (Input.GetKey(KeyCode.W)) ? true : false;
        reset = (Input.GetKeyDown(KeyCode.R)) ? true : false;
    }


}
