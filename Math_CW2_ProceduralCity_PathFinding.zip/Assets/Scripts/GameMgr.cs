﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Singleton;

public class GameMgr : SingleStaticInstance<GameMgr>
{
   public List<GameState.SceneInfo> sceneList { get { return _sceneList; } }
    private List<GameState.SceneInfo> _sceneList;

    public void enterGame(int index)
    {               
        GameState.Instance.loadScene(_sceneList[index].name, _sceneList[index].id, _sceneList[index].natureChance);
        changeSkybox(index);
    }

    private void changeSkybox(int index)
    {
        string path = _sceneList[index].skyboxPath;
        if(path != null)
        {
            Material skybox = Resources.Load<Material>(path);
            Skybox skyboxCom = Camera.main.GetComponent<Skybox>();
            if (skyboxCom)
            {
                skyboxCom.material = skybox;
            }
        }
    
    }


    public void returnMain()
    {
        
        GameState.Instance.showMainScene();
       
    }


    
    // Start is called before the first frame update
    void Start()
    {
        TextAsset file = Resources.Load<TextAsset>("Files/Scenes");     
        FileParser.ParseSceneList(file.text, out _sceneList);

        GameState.Instance.showMainScene();   

    }

}
