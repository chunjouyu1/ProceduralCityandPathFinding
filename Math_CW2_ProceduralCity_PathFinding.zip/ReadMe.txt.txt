Procedural City and Path Finding

Team Members --
Zihen, Wei (MSc Computer Games Programming/ 33670787)
Yiru, Yu (MSc Virtual and Augmented Reality/ 33671463)
Chun-Jou (Celine), Yu (MA Virtual and Augmented Reality/ 33672921)